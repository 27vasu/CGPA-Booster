document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("loginForm");
  const registerForm = document.getElementById("registerForm");

  if (registerForm) {
    registerForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const email = document.getElementById("regEmail").value;
      const password = document.getElementById("regPassword").value;

      localStorage.setItem("userEmail", email);
      localStorage.setItem("userPassword", password);

      document.getElementById("registerMsg").textContent = "✅ Registered successfully! You can now login.";
      registerForm.reset();
    });
  }

  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const email = document.getElementById("loginEmail").value;
      const password = document.getElementById("loginPassword").value;
      const storedEmail = localStorage.getItem("userEmail");
      const storedPassword = localStorage.getItem("userPassword");

      if (email === storedEmail && password === storedPassword) {
        document.getElementById("loginMsg").textContent = "✅ Login successful!";
      } else {
        document.getElementById("loginMsg").textContent = "❌ Invalid credentials!";
      }
    });
  }
});

