function showMessage() {
  document.getElementById("message").innerText = "Thank you for joining CGPA Booster!";
}
