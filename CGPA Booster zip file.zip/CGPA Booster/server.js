const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

let users = [];

app.post('/register', (req, res) => {
  const { email, password } = req.body;
  const userExists = users.find(u => u.email === email);
  if (userExists) return res.status(400).json({ message: 'User already exists' });
  users.push({ email, password });
  res.json({ message: 'Registration successful' });
});

app.post('/login', (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email && u.password === password);
  if (user) return res.json({ message: 'Login successful' });
  res.status(401).json({ message: 'Invalid credentials' });
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));
