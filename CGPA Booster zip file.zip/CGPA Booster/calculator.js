function addSubject() {
  const container = document.getElementById("subjects-container");
  const newRow = document.createElement("div");
  newRow.className = "subject-row";
  newRow.innerHTML = `
    <input type="text" placeholder="Subject Name" class="subject-name" />
    <input type="number" placeholder="Grade" class="grade" step="0.01" />
    <input type="number" placeholder="Credits" class="credit" />
  `;
  container.appendChild(newRow);
}

function calculateCGPA() {
  const grades = document.querySelectorAll(".grade");
  const credits = document.querySelectorAll(".credit");
  const valueSpan = document.getElementById("cgpa-value");
  const result = document.getElementById("result");

  let totalPoints = 0;
  let totalCredits = 0;

  for (let i = 0; i < grades.length; i++) {
    const grade = parseFloat(grades[i].value);
    const credit = parseFloat(credits[i].value);

    if (!isNaN(grade) && !isNaN(credit)) {
      totalPoints += grade * credit;
      totalCredits += credit;
    }
  }

  if (totalCredits === 0) {
    result.innerHTML = "❌ Please enter valid grades and credits.";
    return;
  }

  const cgpa = (totalPoints / totalCredits).toFixed(2);
  valueSpan.textContent = cgpa;
  valueSpan.classList.add("blink");

  setTimeout(() => {
    valueSpan.classList.remove("blink");
  }, 2000);
}
